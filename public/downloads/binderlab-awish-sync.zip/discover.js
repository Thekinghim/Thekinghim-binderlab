/**
 * Innehållsskript i Awish-panelens egen sida (world: MAIN, dash.awish.vip). Om panelen
 * hämtar orderlistan som JSON med fetch eller XMLHttpRequest noteras ADRESSEN (inte
 * svaret) och lämnas till tillägget via window.postMessage → ./bridge.ts, så att
 * tillägget kan läsa samma API i stället för HTML-tabellen. Inget skickas någon
 * annanstans, och sidan påverkas inte (anropen går igenom oförändrade).
 *
 * Klassiskt skript (inte modul): byggskriptet tar bort raden "export {}".
 */
(() => {
    const w = window;
    if (w.__binderlabAwishDiscover)
        return;
    w.__binderlabAwishDiscover = true;
    const ORDER_KEY = /^(?:order_?(?:no|sn|number|num|id|code)|out_?trade_?no|trade_?no)$/i;
    let reported = "";
    const looksLikeOrders = (json, depth = 0) => {
        if (depth > 3 || json === null || typeof json !== "object")
            return false;
        if (Array.isArray(json)) {
            const first = json.find((x) => x && typeof x === "object" && !Array.isArray(x));
            return Boolean(first && Object.keys(first).some((k) => ORDER_KEY.test(k)));
        }
        return Object.values(json).some((v) => looksLikeOrders(v, depth + 1));
    };
    const report = (url, text) => {
        try {
            const absolute = new URL(url, location.href);
            if (absolute.origin !== location.origin)
                return;
            if (!/^\s*[[{]/.test(text))
                return;
            if (!looksLikeOrders(JSON.parse(text)))
                return;
            const href = absolute.toString();
            if (href === reported)
                return;
            reported = href;
            window.postMessage({ source: "binderlab-awish-sync", type: "awish-api", url: href }, location.origin);
        }
        catch {
            // Inte JSON, eller inte ordrar: inget att göra.
        }
    };
    const originalFetch = w.fetch;
    w.fetch = async function (input, init) {
        const response = await originalFetch.call(this, input, init);
        try {
            const url = typeof input === "string" ? input : input instanceof URL ? input.toString() : input.url;
            if (/json|javascript/i.test(response.headers.get("content-type") ?? "")) {
                response
                    .clone()
                    .text()
                    .then((t) => report(url, t))
                    .catch(() => undefined);
            }
        }
        catch {
            // Får aldrig störa sidan.
        }
        return response;
    };
    const open = w.XMLHttpRequest.prototype.open;
    w.XMLHttpRequest.prototype.open = function (method, url, ...rest) {
        this.addEventListener("load", () => {
            try {
                if (this.responseType === "" || this.responseType === "text")
                    report(String(url), this.responseText);
                else if (this.responseType === "json")
                    report(String(url), JSON.stringify(this.response));
            }
            catch {
                // Får aldrig störa sidan.
            }
        });
        return open.call(this, method, url, ...rest);
    };
})();
