/**
 * De delar av Chromes tilläggs-API som tillägget använder, med typer (projektet har inte
 * @types/chrome). Inget globalt: filerna hämtar `chromeApi` härifrån.
 */
export const chromeApi = globalThis.chrome;
