/**
 * Avläsning av Awish orderlista (dash.awish.vip/dashboard/orders/index), oberoende av
 * hur sidan hämtades. Rena funktioner: används av tilläggets service worker och
 * offscreen-dokument, och testas i src/import/adapters/awish-extension-reader.test.ts.
 *
 * Två källor:
 * - HTML-tabellen: kolumnerna hittas på rubriktexterna (ID, Date, Name, Order No.,
 *   Order Machine, Payment Method, Order Amount, Is Paid, Payment Time, Actions), aldrig
 *   på kolumnordningen. Okänsligt för skiftläge, mellanslag och skiljetecken.
 * - JSON (om panelen laddar tabellen via XHR/fetch): raderna hittas i svaret
 *   (rows, data, list, records, ...) och fälten på nycklarnas namn (order_no, goods_name,
 *   machine_name, pay_time, ...). Belopp och betalstatus kräver entydiga nycklar
 *   (order_amount/amount, is_paid/pay_status/payment_status): en allmän "status",
 *   "price" eller "pay_amount" tas aldrig, och då läses HTML-tabellen i stället.
 *
 * Värdena skickas som källans text (beloppscellen "Amount: 170.00", "Paid Success",
 * Payment Time i källans tid): Binderlab tolkar dem med samma regler som en uppladdad
 * CSV. Bara när JSON har ett tal i stället för text skrivs det om (tidsstämpel → ISO
 * med Z, 1/0 → Paid Success/Unpaid).
 */
export const REQUIRED_FIELDS = [
    "externalId",
    "title",
    "machine",
    "amount",
    "isPaid",
    "paidAt",
];
// ---------------------------------------------------------------------------
// Rubriker och nycklar
// ---------------------------------------------------------------------------
/** Gemener, NFKC, bara bokstäver och siffror ("Order No." → "orderno"). Samma som servern. */
export function normalizeHeader(header) {
    return header
        .normalize("NFKC")
        .toLowerCase()
        .replace(/[^\p{L}\p{N}]+/gu, "");
}
/** Synonymer per fält, normaliserade. Ordningen avgör när flera kolumner passar. */
const SYNONYMS = {
    externalId: [
        "orderno",
        "ordernumber",
        "ordernr",
        "ordersn",
        "orderid",
        "outtradeno",
        "tradeno",
        "ordernummer",
        "订单号",
        "订单编号",
    ],
    title: [
        "name",
        "productname",
        "goodsname",
        "goodstitle",
        "product",
        "itemname",
        "title",
        "produkt",
        "goods",
        "item",
        "商品名称",
        "商品",
    ],
    machine: [
        "ordermachine",
        "machinename",
        "machine",
        "devicename",
        "device",
        "automat",
        "设备名称",
        "设备",
    ],
    // Aldrig "Pay Amount", "Paid Amount", "Price" eller "Discount Amount": bara orderns belopp.
    amount: ["orderamount", "amount", "totalamount", "belopp", "订单金额", "金额"],
    // Aldrig en allmän "Status" (orderstatus, återbetald, ...): bara betalstatus.
    isPaid: ["ispaid", "paid", "paystatus", "paymentstatus", "paystate", "betald", "支付状态"],
    paidAt: ["paymenttime", "paytime", "paidtime", "paidat", "paymentat", "betaltid", "支付时间"],
    paymentMethod: [
        "paymentmethod",
        "paymethod",
        "paytype",
        "paymenttype",
        "payway",
        "betalmetod",
        "支付方式",
    ],
    rowId: ["id"],
    orderDate: [
        "date",
        "orderdate",
        "ordertime",
        "createtime",
        "createdat",
        "addtime",
        "datum",
        "创建时间",
    ],
};
/**
 * Nycklar i JSON-svar. Strängare än rubrikerna: i ett API betyder "status", "paid",
 * "price", "money" eller "pay_amount" ofta något annat än orderns belopp och om den är
 * betald, och ett tal (1/0) skrivs om till "Paid Success". Saknas en entydig nyckel för
 * belopp eller betalstatus används inte JSON alls (HTML-tabellen läses i stället).
 */
const JSON_SYNONYMS = {
    ...SYNONYMS,
    amount: ["orderamount", "amount"],
    isPaid: ["ispaid", "paystatus", "paymentstatus"],
};
const FIELDS = Object.keys(SYNONYMS);
/** Kolumnindex per fält (−1 = saknas). Varje kolumn används högst en gång. */
export function mapColumns(headers, synonymsByField = SYNONYMS) {
    const normalized = headers.map(normalizeHeader);
    const used = new Set();
    const out = Object.fromEntries(FIELDS.map((f) => [f, -1]));
    // Fält med specifika namn först, så att "Order Amount" inte tas av något annat.
    for (const field of FIELDS) {
        const synonyms = synonymsByField[field];
        let best = -1;
        let bestRank = Number.POSITIVE_INFINITY;
        normalized.forEach((h, i) => {
            if (used.has(i))
                return;
            const rank = synonyms.indexOf(h);
            if (rank >= 0 && rank < bestRank) {
                best = i;
                bestRank = rank;
            }
        });
        if (best >= 0) {
            used.add(best);
            out[field] = best;
        }
    }
    return out;
}
/** Mappningen med JSON-nycklarnas regler (se JSON_SYNONYMS). */
export function mapJsonKeys(keys) {
    return mapColumns(keys, JSON_SYNONYMS);
}
export function missingFields(columns) {
    return REQUIRED_FIELDS.filter((f) => columns[f] < 0);
}
/** Rubriken eller nyckeln per fält som används (för rapporten). */
function mappingOf(columns, names) {
    const out = {};
    for (const f of FIELDS) {
        const name = columns[f] < 0 ? undefined : names[columns[f]];
        if (name !== undefined)
            out[f] = name.slice(0, 100);
    }
    return out;
}
/**
 * Är raderna sorterade äldst först? Bara när alla rader har ett numeriskt ID och minst
 * tre rader ökar hela vägen. Synken förutsätter nyast först (den slutar läsa vid kända
 * ordernummer), så en lista som visar äldst först får inte användas.
 */
export function looksAscending(rows) {
    if (rows.length < 3)
        return false;
    const ids = rows.map((r) => (r.rowId && /^\d{1,15}$/.test(r.rowId) ? Number(r.rowId) : NaN));
    if (ids.some((n) => !Number.isFinite(n)))
        return false;
    for (let i = 1; i < ids.length; i += 1)
        if (!(ids[i] > ids[i - 1]))
            return false;
    return true;
}
/**
 * Rättar till tabeller som ritats i delar: en tabell utan rubrikrad vars första rad är
 * rubrikerna, och en fast rubrik i en egen tabell följd av raderna i nästa (Bootstrap
 * Table, Layui och liknande ritar så).
 */
export function normalizeTables(tables) {
    const promote = (t) => {
        const first = t.rows[0];
        if (t.headers.length === 0 && first && missingFields(mapColumns(first)).length === 0) {
            return { headers: first, rows: t.rows.slice(1) };
        }
        return t;
    };
    const out = [];
    for (let i = 0; i < tables.length; i += 1) {
        const t = promote(tables[i]);
        const next = tables[i + 1];
        if (t.headers.length > 0 && t.rows.length === 0 && next && next.headers.length === 0) {
            out.push({ headers: t.headers, rows: next.rows });
            i += 1;
            continue;
        }
        out.push(t);
    }
    return out;
}
/** Tabellen med orderlistan: den som har alla obligatoriska kolumner och flest fält. */
export function findOrderTable(tables) {
    let best = null;
    let bestScore = -1;
    for (const t of normalizeTables(tables)) {
        const columns = mapColumns(t.headers);
        if (missingFields(columns).length > 0)
            continue;
        const score = FIELDS.filter((f) => columns[f] >= 0).length * 10_000 + t.rows.length;
        if (score > bestScore) {
            best = t;
            bestScore = score;
        }
    }
    return best;
}
function clean(text) {
    return (text ?? "")
        .replace(/ /g, " ")
        .replace(/[ \t\f\v]+/g, " ")
        .replace(/ *\n */g, "\n")
        .replace(/\n{2,}/g, "\n")
        .trim();
}
/** Raderna i en tabell (rubrikerna hittas på texten). */
export function readGrid(grid, page) {
    const columns = mapColumns(grid.headers);
    const missing = missingFields(columns);
    if (missing.length > 0) {
        throw new ReaderError("layout", `Orderlistan saknar kolumner: ${missing.join(", ")}. Awish kan ha ändrat sidan.`);
    }
    const cell = (row, field) => columns[field] < 0 ? "" : clean(row[columns[field]]);
    const rows = [];
    let skipped = 0;
    let seen = 0;
    grid.rows.forEach((r, i) => {
        // Tomma rader och "Inga data"-rader (en cell över hela bredden) räknas inte.
        if (r.length <= 1 && clean(r[0]).length < 40 && !/\d{4}/.test(clean(r[0])))
            return;
        seen += 1;
        const externalId = cell(r, "externalId");
        if (externalId === "") {
            skipped += 1;
            return;
        }
        rows.push({
            externalId,
            title: cell(r, "title"),
            machine: cell(r, "machine"),
            amount: cell(r, "amount"),
            isPaid: cell(r, "isPaid"),
            paidAt: cell(r, "paidAt"),
            paymentMethod: columns.paymentMethod < 0 ? null : cell(r, "paymentMethod"),
            rowId: columns.rowId < 0 ? null : cell(r, "rowId"),
            orderDate: columns.orderDate < 0 ? null : cell(r, "orderDate"),
            page,
            pageRow: i + 1,
        });
    });
    return {
        rows,
        columns: mappingOf(columns, grid.headers.map(clean)),
        absent: columns.paymentMethod < 0 ? ["paymentMethod"] : [],
        seen,
        skipped,
    };
}
// ---------------------------------------------------------------------------
// Inloggning och sidnavigering
// ---------------------------------------------------------------------------
export class ReaderError extends Error {
    kind;
    constructor(kind, message) {
        super(message);
        this.kind = kind;
        this.name = "ReaderError";
    }
}
const LOGIN_PATH = /\/(?:login|signin|sign-in|auth|passport)(?:[/?.#]|$)/i;
/** Är sidan en inloggningssida (eller en omdirigering dit)? */
export function looksLoggedOut(page, finalUrl) {
    let path = "";
    try {
        const u = new URL(finalUrl);
        path = `${u.pathname}${u.search}`;
    }
    catch {
        path = finalUrl;
    }
    if (LOGIN_PATH.test(path))
        return true;
    const hasOrders = findOrderTable(page.tables) !== null;
    if (hasOrders)
        return false;
    return page.hasPasswordInput || /\b(?:log ?in|sign ?in)\b|登录|logga in/i.test(page.title);
}
const PAGE_PARAMS = ["page", "p", "pagenum", "pageno", "pageindex", "current", "pn"];
/** Sidnumret i en länk (?page=3), och vilken parameter som bär det. */
function pageOf(href, base) {
    try {
        const u = new URL(href, base);
        for (const [key, value] of u.searchParams) {
            if (PAGE_PARAMS.includes(key.toLowerCase()) && /^\d{1,7}$/.test(value)) {
                return { param: key, page: Number(value) };
            }
        }
    }
    catch {
        return null;
    }
    return null;
}
/** Sidnavigeringen på en sida: parameter, sista sidan och om det finns en nästa. */
export function readPagination(page, currentPage, baseUrl, pageSize = 20) {
    let param = "page";
    let lastPage = null;
    let hasNext = false;
    for (const link of page.links) {
        const p = pageOf(link.href, baseUrl);
        if (!p)
            continue;
        param = p.param;
        lastPage = Math.max(lastPage ?? 0, p.page);
        // En länk till sidan efter den här (siffran, "Next", "›", "»" ...) betyder att det
        // finns fler sidor. En inaktiv "Next" på sista sidan saknar oftast href med sidnummer.
        const disabled = /disabled/.test(link.className);
        if (p.page === currentPage + 1 && !disabled)
            hasNext = true;
    }
    const total = /(?:total|totalt|共|showing[^\d]*\d+\s*(?:to|-)\s*\d+\s*of)\s*[:：]?\s*([\d\s,]{1,12})\s*(?:条|rows|rader|entries|records|items)?/i.exec(page.text);
    if (total?.[1]) {
        const n = Number(total[1].replace(/[\s,]/g, ""));
        if (Number.isFinite(n) && n > 0) {
            lastPage = Math.max(lastPage ?? 0, Math.ceil(n / pageSize));
        }
    }
    if (lastPage !== null && currentPage < lastPage)
        hasNext = true;
    return { param, lastPage, hasNext };
}
/** Adressen till sida n, med samma parameter som sidnavigeringen använder. */
export function pageUrl(baseUrl, page, param = "page") {
    const u = new URL(baseUrl);
    u.searchParams.set(param, String(page));
    return u.toString();
}
function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
}
const ROW_KEYS = ["rows", "data", "list", "records", "items", "result", "orders", "lists"];
const TOTAL_KEYS = ["total", "count", "totalcount", "totalrows", "totalelements", "recordstotal"];
function looksLikeOrders(items) {
    const first = items.find(isRecord);
    if (!first)
        return false;
    const columns = mapJsonKeys(Object.keys(first));
    return columns.externalId >= 0 && (columns.amount >= 0 || columns.title >= 0);
}
/** Raderna och totalen i ett JSON-svar, eller null om svaret inte ser ut som ordrar. */
export function findJsonRows(json) {
    const queue = [
        { value: json, depth: 0, total: null },
    ];
    while (queue.length > 0) {
        const { value, depth, total } = queue.shift();
        if (Array.isArray(value)) {
            if (value.length === 0) {
                // En tom lista på rätt nyckel betyder "inga fler rader".
                return { items: [], total };
            }
            if (looksLikeOrders(value)) {
                return { items: value.filter(isRecord), total };
            }
            continue;
        }
        if (!isRecord(value) || depth > 3)
            continue;
        let here = total;
        for (const [k, v] of Object.entries(value)) {
            if (TOTAL_KEYS.includes(normalizeHeader(k)) &&
                (typeof v === "number" || /^\d+$/.test(String(v)))) {
                here = Number(v);
            }
        }
        for (const key of ROW_KEYS) {
            const entry = Object.entries(value).find(([k]) => k.toLowerCase() === key);
            if (entry)
                queue.push({ value: entry[1], depth: depth + 1, total: here });
        }
    }
    return null;
}
/** Är ett JSON-svar ett "inte inloggad"-svar? */
export function jsonLoggedOut(json) {
    if (!isRecord(json))
        return false;
    const code = json.code ?? json.status ?? json.errcode;
    const msg = String(json.msg ?? json.message ?? json.error ?? "");
    const url = String(json.url ?? json.redirect ?? "");
    return (code === 401 ||
        code === "401" ||
        LOGIN_PATH.test(url) ||
        /not ?log(?:ged)? ?in|please log ?in|unauthori[sz]ed|login required|请登录|未登录|登录超时/i.test(msg));
}
function pad(n) {
    return String(n).padStart(2, "0");
}
/** Ett JSON-värde som text. Tal som ser ut som tidsstämplar blir ISO med Z. */
function textOf(value, field) {
    if (value === null || value === undefined)
        return "";
    if (typeof value === "boolean") {
        return field === "isPaid" ? (value ? "Paid Success" : "Unpaid") : String(value);
    }
    if (typeof value === "number") {
        if (field === "paidAt" || field === "orderDate") {
            const ms = value > 1e12 ? value : value > 1e9 ? value * 1000 : NaN;
            if (Number.isFinite(ms)) {
                const d = new Date(ms);
                return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}T${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}:${pad(d.getUTCSeconds())}Z`;
            }
        }
        if (field === "isPaid")
            return value === 1 ? "Paid Success" : "Unpaid";
        if (field === "amount")
            return value.toFixed(2);
        return String(value);
    }
    if (isRecord(value)) {
        // Inbäddade objekt, t.ex. { machine: { name: "..." } } eller { goods: { title: "..." } }.
        for (const key of ["name", "title", "text", "label", "value"]) {
            if (key in value)
                return textOf(value[key], field);
        }
        return "";
    }
    if (Array.isArray(value))
        return value.map((v) => textOf(v, field)).join(", ");
    const s = String(value).trim();
    if (field === "isPaid" && /^(?:1|true)$/i.test(s))
        return "Paid Success";
    if (field === "isPaid" && /^(?:0|false|-1)$/i.test(s))
        return "Unpaid";
    if ((field === "paidAt" || field === "orderDate") && /^\d{10}(?:\d{3})?$/.test(s)) {
        return textOf(Number(s), field);
    }
    return s
        .replace(/<[^>]*>/g, " ")
        .replace(/\s+/g, " ")
        .trim();
}
/** Raderna i ett JSON-svar. Fälten hittas på nycklarnas namn (som rubrikerna). */
export function readJsonItems(items, page) {
    const keys = [...new Set(items.flatMap((i) => Object.keys(i)))];
    const columns = mapJsonKeys(keys);
    const missing = missingFields(columns);
    if (items.length > 0 && missing.length > 0) {
        throw new ReaderError("layout", `Awish svar saknar entydiga fält: ${missing.join(", ")}. Tillägget läser HTML-tabellen i stället.`);
    }
    const keyOf = (f) => (columns[f] < 0 ? null : (keys[columns[f]] ?? null));
    const get = (item, f) => {
        const k = keyOf(f);
        return k === null ? "" : textOf(item[k], f);
    };
    const rows = [];
    let skipped = 0;
    items.forEach((item, i) => {
        const externalId = get(item, "externalId");
        if (externalId === "") {
            skipped += 1;
            return;
        }
        rows.push({
            externalId,
            title: get(item, "title"),
            machine: get(item, "machine"),
            amount: get(item, "amount"),
            isPaid: get(item, "isPaid"),
            paidAt: get(item, "paidAt"),
            paymentMethod: keyOf("paymentMethod") === null ? null : get(item, "paymentMethod"),
            rowId: keyOf("rowId") === null ? null : get(item, "rowId"),
            orderDate: keyOf("orderDate") === null ? null : get(item, "orderDate"),
            page,
            pageRow: i + 1,
        });
    });
    return {
        rows,
        columns: mappingOf(columns, keys),
        absent: keyOf("paymentMethod") === null ? ["paymentMethod"] : [],
        seen: items.length,
        skipped,
    };
}
const SIZE_PARAMS = ["limit", "pagesize", "size", "rows", "perpage", "per_page", "length", "ps"];
const OFFSET_PARAMS = ["offset", "start", "skip"];
/**
 * Sökvägar som får användas som orderkälla i JSON: orderlistans egen adress
 * (ordersPath, med eller utan .html/index) och ett API som uttryckligen är en orderlista
 * (".../order/list", ".../orders/index"). Allt annat som panelen anropar (återbetalningar,
 * topplistor på startsidan, statistik ...) avvisas, även om svaret har ordernummer.
 */
export function isOrdersApiPath(pathname, ordersPath) {
    const strip = (p) => p.replace(/\.(?:html|json)$/i, "").replace(/\/+$/, "");
    const path = strip(pathname).toLowerCase();
    const own = strip(ordersPath).toLowerCase();
    if (path === own || path === own.replace(/\/index$/, ""))
        return true;
    if (/refund|after_?sale|statistic|stats|rank|top|summary|report|export|chart/.test(path)) {
        return false;
    }
    return /^(?:\/[a-z0-9_-]+){0,3}\/orders?\/(?:index|list|lists|getlist|page)$/.test(path);
}
/**
 * Tolkar adressen som panelen själv anropade och tar fram hur sidorna bläddras.
 *
 * Bara sökvägen behålls: panelens filter, sökning och sortering (filter, op, search,
 * sort, order ...) gäller det användaren tittade på i panelen, inte hela orderlistan.
 * I stället begärs alltid "sort=id&order=desc" (nyast först), som synken förutsätter.
 */
export function jsonApiFromUrl(url, ajaxHeader = true) {
    let u;
    try {
        u = new URL(url);
    }
    catch {
        return null;
    }
    let style = "page";
    let pageParam = "page";
    let sizeParam = "limit";
    let pageSize = 20;
    for (const [key, value] of [...u.searchParams]) {
        const k = key.toLowerCase();
        if (OFFSET_PARAMS.includes(k)) {
            style = "offset";
            pageParam = key;
            u.searchParams.delete(key);
        }
        else if (PAGE_PARAMS.includes(k)) {
            style = "page";
            pageParam = key;
            u.searchParams.delete(key);
        }
        else if (SIZE_PARAMS.includes(k.replace(/_/g, "")) || SIZE_PARAMS.includes(k)) {
            sizeParam = key;
            const n = Number(value);
            if (Number.isInteger(n) && n > 0 && n <= 500)
                pageSize = n;
            u.searchParams.delete(key);
        }
    }
    u.search = "";
    u.hash = "";
    u.searchParams.set("sort", "id");
    u.searchParams.set("order", "desc");
    return { url: u.toString(), style, pageParam, sizeParam, pageSize, ajaxHeader };
}
/** Adressen till sida n (från 1) i JSON-API:t. */
export function jsonPageUrl(api, page) {
    const u = new URL(api.url);
    u.searchParams.set(api.sizeParam, String(api.pageSize));
    u.searchParams.set(api.pageParam, String(api.style === "offset" ? (page - 1) * api.pageSize : page));
    return u.toString();
}
